var bookWidth = 0;
var bookMinWidth = 0;
var bookScale = 1.2
var topMenuWidth = 242;

var browserName = "";
var browserPrefix = "";
var isIE = false;
var versionIE = 9;

function browserVer() {

    var browser = navigator.userAgent.toLowerCase();
    var platform = navigator.platform.toLowerCase();
    //���������� ��������� ��� �������� ���������� �� ������������
    var UA = browser.match(/(opera|ie|firefox|chrome|version)[\s\/:]([\w\d\.]+)?.*?(safari|version[\s\/:]([\w\d\.]+)|$)/) || [null, 'unknown', 0];


    //������������� ������� browser
    browserName = (UA[1] == 'version') ? UA[3] : UA[1]; //��-�� ��������� ���������� ����� ���� �� �������


    switch (browserName) {
        case 'safari':
            browserPrefix = 'webkit';
            break
        case 'firefox':
            browserPrefix = 'Moz';
            break
        case 'opera':
            browserPrefix = 'O';
            break
        case 'ie':
            browserPrefix = 'ms';
            isIE = true;
            //���������� ��������� ��
            if (document.all && !document.querySelector) {
                //alert('IE7 ��� ����');
                versionIE = 7;
            }

            if (document.all && document.querySelector && !document.getElementsByClassName) {
                //alert('IE8');
                versionIE = 8;
            }
            break
        case 'chrome':
            browserPrefix = 'webkit';
            break
        case 'unknown':
            browserPrefix = 'webkit';
            break
    };

}

function rotateContent(elem, angle) {

    if (angle) {
        angle = angle.replace(",", ".");

        if (angle * 1 != 0) {


            if (isIE) {
                elem.style.overflow = "visible";

                var divWidthIn = 0;

                var sizeopt = { w: elem.offsetWidth, h: elem.offsetHeight };
                var cos = Math.cos(angle);
                var sin = Math.sin(angle);
                
                if(angle < 0){
                   angle = angle - Math.floor(angle/(2*Math.PI))*2*Math.PI; 
                }                
                angle = angle%(2*Math.PI);


                if (versionIE != 9) {
                    var filter = 'progid:DXImageTransform.Microsoft.Matrix(sizingMethod="auto expand", M11 = ' + cos + ', M12 = ' + (-sin) + ', M21 = ' + sin + ', M22 = ' + cos + ')';
                    elem.style.filter = filter;

                    var w = elem.offsetWidth;
                    var h = elem.offsetHeight;

                    if (Math.PI / 2 <= angle && angle < Math.PI) {
                        elem.style.marginLeft = Math.round(sizeopt.w * cos) + "px";
                    } else if (Math.PI <= angle && angle < 3 * Math.PI / 2) {
                        elem.style.marginLeft = Math.round(sizeopt.w * cos) + "px";
                        elem.style.marginTop = Math.round(sizeopt.w * sin) + "px";
                    } else if (3 * Math.PI / 2 <= angle && angle < 2 * Math.PI) {
                        elem.style.marginTop = Math.round(sizeopt.w * sin) + "px";
                    }

                } else {
                    elem.style[browserPrefix + 'TransformOrigin'] = "0 0 0";
                    elem.style[browserPrefix + 'Transform'] = " rotate(" + angle * 180 / Math.PI + "deg)";
                    elem.style.marginLeft = Math.round(sizeopt.w *(cos-1)/2) + "px";
                    elem.style.marginTop = Math.round(sizeopt.w * sin /2) + "px";
                }



            } else {

                elem.style[browserPrefix + 'TransformOrigin'] = "0 0 0";
                elem.style[browserPrefix + 'Transform'] = " rotate(" + angle * 180 / Math.PI + "deg)";

            }
        }
    }

}

function checkTopMenu() {

    var tmp1 = document.getElementById("topRightBG");
    var ww1 = document.getElementById("fullVersionLink").offsetWidth;
    if (ww1 > tmp1.offsetWidth) {
        tmp1.style.width = (ww1 + 10) + "px";
        document.getElementById("topLine").style.right = (ww1 + 10 + 4) + 'px';
        document.getElementById("topLeftBG").style.right = (ww1 + 10 + 4) + 'px';
        document.getElementById("topLeft").style.right = (ww1 + 10 + 4 + 117) + 'px';

    }

    var tmp2 = document.getElementById("topLeftBG");
    var ww2 = document.getElementById("tocLink").offsetWidth;
    if (ww2 > tmp2.offsetWidth) {
        tmp2.style.width = (ww2 + 10) + "px";
        document.getElementById("topLeft").style.right = (4 + ww1 + 10 + ww2 + 10) + 'px';
    }

    var tmp3 = document.getElementById("prewKnob");
    var ww3 = document.getElementById("prewKnobTxt").offsetWidth;
    if (ww3 > tmp3.offsetWidth) {
        tmp3.style.width = ww3 + 'px';
        tmp3.style.left = (-ww3 - 5) + 'px';
    }
}

function checkTocInit() {
    widthSet();
    // set TOC width
    var tocWidth = bookMinWidth + 300;

    checkTocWidth(tocWidth);
    checkTocHeight();

}

function checkTocHeight() {

    var listH = document.getElementById("divTree").offsetHeight;
    var windowH = window.innerHeight;
    var pageH = document.getElementById("divPage");


    // stretch  PAGE to window height
    if (pageH.offsetHeight < 1 * windowH - 250) {
        pageH.style.height = (1 * windowH - 250) + 'px';
    }

    // correct Knobs position
    document.getElementById("nextKnob").style.top = (pageH.offsetHeight / 2) + 'px';
    document.getElementById("prewKnob").style.top = (pageH.offsetHeight / 2) + 'px';

    // stretch PAGE to LIST size  
    if (listH > pageH.offsetHeight - 150) {  // 150 bottom margin        
        pageH.style.height = (1 * listH + 150) + 'px';
        document.getElementById("divBG").style.height = (1 * listH) + 'px';

    }

}


function checkTocWidth(ww) {

    document.getElementById("divTitleHeader").style.width = ww + 'px';
    document.getElementById("fontTitle").style.width = ww + 'px';
    document.getElementById("divPage").style.width = ww + 'px';
    document.getElementById("divMain").style.width = ww + 'px';
    document.getElementById("divTOCHeader").style.width = (ww - 120) + 'px';
    document.getElementById("divTree").style.width = (ww - 140) + 'px';

    document.getElementById("topRight").style.right = '0px';
    document.getElementById("topRightBG").style.right = '4px';
    document.getElementById("topLine").style.right = '121px';
    document.getElementById("topLeftBG").style.right = '121px';
    document.getElementById("topLeft").style.right = '238px';

    document.getElementById("nextKnob").style.left = (ww + 5) + 'px';

    if (document.getElementById("divCopy")) {
        document.getElementById("divCopy").style.right = '0px';
    }

    var www = document.getElementById("divTitleHeader").offsetWidth;
    if (www > ww - topMenuWidth) {
        document.getElementById("fontTitle").style.padding = "40px 0 40px 0";
        document.getElementById("fontTitle").style.width = (www) + "px";
    }
}

function checkPageInit() {
    browserVer();
    widthSet();

    if (bookWidth < bookMinWidth) {

        bookScale = bookMinWidth / bookWidth;
        zoom(bookScale);
        bookWidth = bookMinWidth;


    } else if (bookWidth > window.innerWidth - 300) {
        if (bookMinWidth > window.innerWidth - 300) {
            bookScale = bookMinWidth / bookWidth;
            zoom(bookScale);
            bookWidth = bookMinWidth;

        } else {
            bookScale = (window.innerWidth - 300) / bookWidth;
            zoom(bookScale);
            bookWidth = window.innerWidth - 300;
        }

    } else {
        zoom(bookScale);
    }

    checkPageWidth();
    checkPageHeight();


}

function checkPageHeight() {           // TODO - �������� �������� ������ ���� ��
    var hh = document.getElementById("divBookPage").offsetHeight;

    document.getElementById("divPage").style.height = (1 * hh) + 'px';
    document.getElementById("divMain").style.height = (1 * hh + 100) + 'px';
    document.getElementById("divBG").style.height = (1 * hh - 150) + 'px';
    document.getElementById("nextKnob").style.top = ((hh - 70) / 2) + 'px';
    document.getElementById("prewKnob").style.top = ((hh - 70) / 2) + 'px';
}

function checkPageWidth() {
    var ww = document.getElementById("divBookPage").offsetWidth;

    document.getElementById("divTitleHeader").style.width = ww + 'px';
    document.getElementById("fontTitle").style.width = ww + 'px';
    document.getElementById("divPage").style.width = ww + 'px';
    document.getElementById("divMain").style.width = ww + 'px';

    document.getElementById("topRight").style.right = '0px';
    document.getElementById("topRightBG").style.right = '4px';
    document.getElementById("topLine").style.right = '121px';
    document.getElementById("topLeftBG").style.right = '121px';
    document.getElementById("topLeft").style.right = '238px';

    document.getElementById("nextKnob").style.left = (ww + 5) + 'px';


    if (document.getElementById("divCopy")) {
        document.getElementById("divCopy").style.right = '0px';
    }

    var www = document.getElementById("divTitleHeader").offsetWidth;
    if (www > ww - topMenuWidth) {
        document.getElementById("fontTitle").style.padding = "40px 0 40px 0";
        document.getElementById("fontTitle").style.width = (www) + "px";
    }
}

function widthSet() {
    bookWidth = document.getElementById("divMain").offsetWidth;
    var pW1 = document.getElementById("fullVersionLink").offsetWidth;
    var dW1 = document.getElementById("topRightBG").offsetWidth;
    var maxW1 = (pW1 > dW1) ? pW1 : dW1;

    var pW2 = document.getElementById("tocLink").offsetWidth;
    var dW2 = document.getElementById("topLeftBG").offsetWidth;
    var maxW2 = (pW2 > dW2) ? pW2 : dW2;

    topMenuWidth = maxW1 + maxW2;
    bookMinWidth = topMenuWidth + 50 + document.getElementById("divSeoVersion").offsetWidth;
    bookScale = 1.2;
}

function zoom(step) {

    // scale text divs  
    var item = document.getElementById('divBookPage');
    var elems = item.childNodes;

    for (var i = 0; i < elems.length; i++) {
        if (elems[i].tagName == "DIV") {
            

            elems[i].style.top = (1 * (elems[i].style.top.replace("px", "")) * step) + "px";
            elems[i].style.left = (1 * (elems[i].style.left.replace("px", "")) * step) + "px";

            elems[i].style.width = (Math.abs(elems[i].style.width.replace("px", "")) * step) + "px";
            elems[i].style.height = (Math.abs(elems[i].style.height.replace("px", "")) * step) + "px";
  
rotateContent(elems[i], elems[i].getAttribute('angle'));
        }
    }
    //  scale font size
    elems = item.getElementsByTagName('span')

    for (var i = 0; i < elems.length; i++) {
        var computedStyle = elems[i].currentStyle || window.getComputedStyle(elems[i], null);
        var divCont = (elems[i].parentNode.tagName == "DIV") ? elems[i].parentNode : elems[i].parentNode.parentNode;


        if (elems[i].style.fontSize) {
            scale = (Math.abs(elems[i].style.fontSize.replace("px", "")) * step);
        } else {
            scale = (Math.abs(computedStyle.fontSize.replace("px", "")) * step);
        }

        elems[i].style.fontSize = scale + "px";

        if (browserName != "ie") {
            while ((elems[i].offsetWidth > divCont.offsetWidth) && (scale > 1)) {
                scale = scale - 1;
                elems[i].style.fontSize = scale + "px";
            }

            var diff = ((divCont.offsetHeight - elems[i].offsetHeight) / 2);
            diff = diff.toFixed();
            if (diff > 0) { elems[i].style.padding = diff + "px 0px"; }
            elems[i].style.top = ((divCont.offsetHeight - elems[i].offsetHeight) / 2) + "px";
        } else {
            var ann = (divCont.getAttribute('angle')) ? divCont.getAttribute('angle').replace(",", ".") * 1 : 0;
            if ((ann > Math.PI / 4 && ann < 3 * Math.PI / 4) || (ann > 5 * Math.PI / 4 && ann < 7 * Math.PI / 4)) {
                while ((elems[i].offsetHeight > divCont.offsetHeight) && (scale > 1)) {
                    scale = scale - 1;
                    elems[i].style.fontSize = scale + "px";
                }
            } else {
                while ((elems[i].offsetWidth > divCont.offsetWidth) && (scale > 1)) {
                    scale = scale - 1;
                    elems[i].style.fontSize = scale + "px";
                }
            }
        }
    }

    //  scale image size and place
    elems = item.getElementsByTagName('img');
    for (var i = 0; i < elems.length; i++) {
        var computedStyle = elems[i].currentStyle || window.getComputedStyle(elems[i], null);
        elems[i].style.top = (1 * elems[i].style.width.replace("px", "") * step) + "px";
        elems[i].style.left = (1 * elems[i].style.width.replace("px", "") * step) + "px";

        elems[i].style.width = (1 * elems[i].style.width.replace("px", "") * step) + "px";
        elems[i].style.height = (1 * elems[i].style.height.replace("px", "") * step) + "px";
    }

    // scale page size 
    computedStyle = item.currentStyle || window.getComputedStyle(item, null);
    if (item.style.width) {
        item.style.width = (1 * item.style.width.replace("px", "") * step) + "px";
    } else {
        item.style.width = (1 * computedStyle.width.replace("px", "") * step) + "px";
    }
    if (item.style.height) {
        item.style.height = (1 * item.style.height.replace("px", "") * step) + "px";
    } else {
        item.style.height = (1 * computedStyle.height.replace("px", "") * step) + "px";
    }

    checkPageWidth();
    checkPageHeight();
}

function checkPublCom() {
    if (document.domain.indexOf('publ.com') != -1) {
        var parts = document.URL.split('/');
        var prevpart = '';
        for (var i = 0; i < parts.length; i++) {
            if (prevpart.toLowerCase() == 'bookdata')
                return replaceBackLink(parts[i]);
            if (parts[i].toLowerCase() == 'seo' || parts[i].toLowerCase() == 'basic-html')
                return replaceBackLink(prevpart);
            prevpart = parts[i];
        }
    }
}

function replaceBackLink(id) {
    var link = document.getElementById('fullVersionLink');
    if (link) {
        var hash = link.href.indexOf('#');
        if (hash != -1)
            link.href = 'http://' + document.domain + '/session/detectbrowser?returnTo=/' + id + '%23' + link.href.substr(hash + 1);
        else
            link.href = 'http://' + document.domain + '/session/detectbrowser?returnTo=/' + id;
    }
}
